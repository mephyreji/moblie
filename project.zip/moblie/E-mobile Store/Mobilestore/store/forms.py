from django import forms
from .models import SProduct





class ProductMForm(forms.ModelForm):
        class Meta:
            model=SProduct
            fields=["title","description","image","price"]
            widgets={
            "title":forms.TextInput(attrs={"class":"form-control"}),
            "description":forms.TextInput(attrs={"class":"form-control"}),
            "image":forms.FileInput(),
            "price":forms.NumberInput(attrs={"class":"form-control"}),            }
       
  
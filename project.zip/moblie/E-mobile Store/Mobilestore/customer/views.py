from django.shortcuts import render,redirect
from django.urls import reverse_lazy
from django.views.generic import TemplateView,CreateView
from store.models import SProduct
from .models import *
from django.contrib import messages
from .forms import Cartform
# Create your views here.

class CustHome(TemplateView):
    template_name="chome.html"
    def get_context_data(self, **kwargs):
        context=super().get_context_data(**kwargs)
        context['products']=SProduct.objects.all()
        return context

class CartView(TemplateView):
    template_name="cart.html"
    def get_context_data(self, **kwargs):
        context=super().get_context_data(**kwargs)
        context['cartitems']=CartItem.objects.filter(user=self.request.user)
        return context

class AddCart(CreateView):
    template_name="addcart.html"
    form_class=Cartform
    model=CartItem
    success_url=reverse_lazy("cart")
    def get_context_data(self, **kwargs):
        context=super().get_context_data(**kwargs)
        context['pro']=SProduct.objects.get(id=self.kwargs.get("pid"))
        return context
    def form_valid(self, form):
        form.instance.user=self.request.user
        form.instance.product=SProduct.objects.get(id=self.kwargs.get("pid"))
        self.object=form.save()
        return super().form_valid(form)
    
class CheckView(TemplateView):
    template_name="checkout.html"


def AddReview(request,bid):
    if request.method == 'POST':
        review = request.POST.get('comment')
        CustUser = request.CustUser
        Product.objects.create(user=CustUser, comment=review)
        messages.success(request, 'Review Added!')
        return redirect('')

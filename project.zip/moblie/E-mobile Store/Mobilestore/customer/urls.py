from django.urls import path
from .views import *

urlpatterns=[
    path("custhome",CustHome.as_view(),name="chome"),
    path("cart",CartView.as_view(),name="cart"),
    path("checkout",CheckView.as_view(),name="c_out"),
    path("addcart/<int:pid>",AddCart.as_view(),name="addcart"),
    # path('add_review', AddReview.as_view(), name='review'),

]